from pso import PSO
import math
import time

if __name__ == '__main__':
    start_time = time.time()
    n = 30
    min_bound = -500
    max_bound = 500

    num_particles = 10000

    iter = 100

    w = 0.5

    local_best_pos = 2

    global_best_sol = 1

    def fitness(position):
        sum = 0
        for x_i in position:
            abs_x = abs(x_i)
            
            sqrt_x = math.sqrt(abs_x)

            sin_x = math.sin(sqrt_x)

            term = -x_i*sin_x

            sum += term
        return sum
    
    pso = PSO(n, min_bound, max_bound, num_particles, iter, w, local_best_pos, global_best_sol, fitness)
    best_position, best_value = pso.run()
    end_time = time.time()
    result_time = end_time - start_time
    print(best_position)
    print(best_value)
    print("Tiempo de ejecución: " + f"{result_time:.3f}" + " segundos")            